﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRO2_DABD1249321
{
    public partial class MatrizForm : Form
    {
        ChekFile MatrizData = new ChekFile();
        int almacen_fila; int almacen_columna; string almacen; string robot; int capacidad;
        string[,] DataCSV;
        
        public MatrizForm()
        {
            this.DataCSV = this.MatrizData.MatrizParaLeer();
            InitializeComponent(this.DataCSV);
        }
        public void BT0_1_Click(object sender, EventArgs e)
        {
            //MoveRobot();
            VentaInicial VentanaI = new VentaInicial();
            VentanaI.Show();
        }
        public void BT0_2_Click(object send, EventArgs e)
        {
            this.Close();
        }
        public void MoveRobot()
        {
            this.ROBOT_1.Location = new Point(4 * 89 + 15, 4 * 89 + 15);
        }
    }
}
